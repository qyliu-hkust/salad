// This file is part of PGM-index <https://github.com/gvinciguerra/PGM-index>.
// Copyright (c) 2018 Giorgio Vinciguerra.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once
#include <immintrin.h>

#include <climits>
#include <iostream>
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <iterator>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>
// #include <typeinfo>
#include <cmath>
#include "sdsl/bits.hpp"
#include "sdsl/int_vector.hpp"
#include "tools.hpp"
#include "piecewise_linear_model.hpp"

namespace pgm
{
    #define BIT_CEIL(x) ((x) < 2 ? 1u : 1u << (64u - __builtin_clzll((x) - 1))) // 计算x的上取整的2的幂次方
    #define BIT_WIDTH(x) ((x) == 0 ? 0 : 64 - __builtin_clzll(x)) // 计算x的位宽，即x的二进制表示中最高位1的位置

    template <typename K, uint64_t Epsilon = 64, uint64_t EpsilonRecursive = 0, typename Floating = float>
    // template <typename K, uint64_t Epsilon = 64, uint64_t EpsilonRecursive = 0, typename Floating = double>
    class PGMIndex {
    public:

        static_assert(Epsilon > 0);

        struct Segment;

        typedef int64_t Simd_Value;
        typedef int32_t Correction_Value;
        typedef int32_t Intercept_Value;
        typedef uint32_t Covered_Value;

        uint64_t n;                           ///< The number of elements this index was built on.
        K first_pos;                     ///< The smallest element.
        std::vector<Segment> segments;      ///< The segments composing the index.
        std::vector<uint64_t> levels_offsets; ///< The starting position of each level in segments[], in reverse order.

        sdsl::bit_vector signs; // signs for saving
        sdsl::int_vector<64> corrections; // corrections for saving
        std::vector<Correction_Value> corrections_vector; // corrections for decode

        /// Sentinel value to avoid bounds checking.
        static constexpr K sentinel = std::numeric_limits<K>::has_infinity ? std::numeric_limits<K>::infinity() : std::numeric_limits<K>::max();

        static constexpr bool auto_bpc = false;
        static constexpr uint64_t cache_line_bits = 64 * CHAR_BIT;
        static constexpr uint64_t extraction_density = auto_bpc ? 1 : BIT_CEIL(4 * cache_line_bits / BIT_WIDTH(Epsilon));

        using position_type = typename std::conditional_t<sizeof(K) <= 4, uint32_t, uint64_t>;
        using larger_signed_key_type = typename std::conditional_t<sizeof(K) <= 4, uint64_t, __int128>;
        using canonical_segment = typename internal::OptimalPiecewiseLinearModel<position_type, K>::CanonicalSegment;

        uint64_t errorPointCount;

        // 构造函数
        PGMIndex(): n(0), errorPointCount(0) {}

        explicit PGMIndex(const std::vector<K>& data) : PGMIndex(data.begin(), data.end()) {}

        template <typename RandomIt>
        PGMIndex(RandomIt begin, RandomIt end):
            n(std::distance(begin, end)),
            first_pos(n ? *begin : K(0)),
            segments(),
            levels_offsets(),
            errorPointCount(0),
            corrections((n) * BIT_WIDTH(Epsilon) / 64 + 5), // 将残差值的位宽除以64，例如1024只需要11的位宽
            signs(n) {
            build(begin, end, Epsilon, EpsilonRecursive, segments, levels_offsets, errorPointCount, corrections,  signs);
        }

        template <typename RandomIt>
        static void build(RandomIt begin, RandomIt end,
                          uint64_t epsilon,
                          uint64_t epsilon_recursive, // 递归构建多层PGM的epsilon，单层中未使用
                          std::vector<Segment>& segments,
                          std::vector<uint64_t>& levels_offsets,
                          uint64_t& errorPointCount,
                          sdsl::int_vector<64>& corrections,
                          sdsl::bit_vector& signs) {

            auto n = (uint64_t) std::distance(begin, end);
            if (n == 0)
                return;

            levels_offsets.push_back(0);
            segments.reserve(n / (epsilon * epsilon));

            if (*std::prev(--end) == sentinel) //如果最后一个元素等于哨兵值，则抛出异常
                throw std::invalid_argument("The value " + std::to_string(sentinel) + " is reserved as a sentinel.");

            uint64_t corrections_offset = 0;

            std::vector<canonical_segment> canonical_segments; // 多个线段数据

            canonical_segments.reserve(epsilon > 0 ? n / (epsilon * epsilon) : n / 8);

            auto in_fun = [begin](auto i) { return std::pair<position_type, K>(i, begin[i]); };
            auto out_fun = [&canonical_segments](auto cs) { canonical_segments.push_back(cs); };
            auto n_segments = internal::make_segmentation_par(n, epsilon, in_fun, out_fun); //n是线段中数据的个数, n_segments是线段的个数
            auto last_n = n_segments;

            for (auto it = canonical_segments.begin(); it < canonical_segments.end(); ++it)
            {
                auto i = it->get_first_x(); // 获取线段的起始位置
                auto j = std::next(it) != canonical_segments.end() ? std::next(it)->get_first_x() : n; // 获取线段的终止位置
                uint8_t bpc = BIT_WIDTH(epsilon); // 误差值的位宽
                segments.emplace_back(*it, n, i, j, begin, errorPointCount, corrections.data(), signs, bpc, corrections_offset); // sign 标记正负, bpc 误差值的位宽, corrections_offset 误差值的偏移
                corrections_offset += bpc * (j - i);
            }
            // segments contains every first pos , interception and slope
            segments.emplace_back(n);
            levels_offsets.emplace_back(segments.size());
        }

        uint64_t segments_count() const { return segments.empty() ? 0 : levels_offsets[1] - 1; }

        uint64_t height() const { return levels_offsets.size() - 1; }

        std::vector<Segment> get_segments() const { return segments; }

        auto segment_for_pos(const K& pos) const {
            return std::prev(std::upper_bound(segments.begin(), segments.begin() + segments_count(), pos));
        }

        uint64_t indexSegments_bytes() const {
            return segments.size() * sizeof(Segment) + levels_offsets.size() * sizeof(uint64_t);
        }

        void decode_init(){
            corrections_vector.resize(n, 0);
            for(auto &s : segments) {
                auto covered = s.covered;
                auto first = s.first;
                for (Covered_Value j = 0; j < covered; ++j)
                    corrections_vector[j + first] = get_correction(corrections.data(), n, j + first, signs);
            }
        }

        uint64_t segment_size_in_bytes() const {
            return segments_count() * sizeof(Segment);
        }

        uint64_t corrections_size_in_bytes() const {
            return corrections.bit_size() / CHAR_BIT;
        }

        uint64_t signs_size_in_bytes() const {
            return signs.bit_size() / CHAR_BIT;
        }

        // used for SIMD
        constexpr static K key_nums = 8;
        constexpr static K align_val = 64; // 对齐值
        std::vector<Simd_Value> signs_Floating; //correction is already Floating
        std::vector<Segment> segments_sort; // 重排线段
        std::vector<Simd_Value*> slope_simd;
        std::vector<Simd_Value*> slope_significand_simd;
        std::vector<Simd_Value*> slope_exponent_simd;
        std::vector<Intercept_Value*> intercept_simd;
        std::vector<Correction_Value*> corrections_simd; // 存储每批线段误差值的地址
        std::vector<Covered_Value*> first_simd;
        std::vector<Covered_Value*> covered_simd; // size_t是unsigned long long
        std::vector<Covered_Value> cover_length;
        Simd_Value correction_pos = 0;
        uint64_t total_calculated = 0;
        uint64_t idx = 0;

        template <typename T>
        T* aligned_new(uint64_t num_elements) {
            void* ptr = std::aligned_alloc(align_val, num_elements * sizeof(T));
            if (!ptr) throw std::bad_alloc();
            return static_cast<T*>(ptr);
        }

        template <typename T>
        void aligned_delete(T* ptr) {
            std::free(ptr);
        }

        void free_memory() {
            for (auto i = 0; i < slope_significand_simd.size(); i++) {
                aligned_delete(slope_significand_simd[i]);
                aligned_delete(slope_exponent_simd[i]);
                aligned_delete(intercept_simd[i]);
                aligned_delete(corrections_simd[i]);
                aligned_delete(first_simd[i]);
                aligned_delete(covered_simd[i]);
            }
        }

        std::vector<Covered_Value> result_map_init() {
            std::vector<Covered_Value> result_map(n);
            Simd_Value pointers = -1;
            // Simd_Value correct_pointers = -1;
            Simd_Value key_nums_tmp = key_nums;
            for(int i = 0; i < slope_significand_simd.size(); i++) {
                Covered_Value *first_tmp = first_simd[i]; // 每个线段的第一个位置
                Covered_Value *cover_tmp = covered_simd[i];
                Covered_Value cover_length_tmp = cover_length[i];

                for (Covered_Value k = 0; k < key_nums_tmp; k++){ // save the data to the right pos{
                    result_map[first_tmp[k]] = ++pointers;
                }

                for (Covered_Value j = 1; j < cover_length_tmp; j++) {
                    for (K k = 0; k < key_nums_tmp; k++) {
                        result_map[first_tmp[k] + j] = ++pointers;
                    }
                }
                for (K k = 0; k < key_nums_tmp; k++) { // 剩余的值用单个循环解码
                    auto first = first_tmp[k];
                    auto covered = cover_tmp[k];
                    if (cover_length_tmp < covered) {
                        for (Covered_Value pos = cover_length_tmp; pos < covered; pos++){
                            result_map[first + pos] = ++pointers;
                            // corrections_vector_residual_size++;
                            // corrections_vector_residual.push_back(corrections_vector[first + pos]);
                        }
                    }
                }
            }
            for(auto it = segments_sort.begin() + idx; it < std::prev(segments_sort.end()); it++) {
                auto& s = *it;
                auto covered = s.covered;
                auto first = s.first;
                for (Covered_Value pos = 0; pos < covered; pos++){
                    result_map[first + pos] = ++pointers;
                    // corrections_vector_residual_size++;
                    // corrections_vector_residual.push_back(corrections_vector[first + pos]);
                }
            }
            return result_map;
        }

        void simd_init_align(bool use_max = true) {
            segments_sort = segments;
            sort(segments_sort.begin(), segments_sort.end());
            Covered_Value max_cover = 0;
            Covered_Value min_cover = INT_MAX;
            Covered_Value max_min_covered = 0;

            // for (typename std::vector<Segment>::iterator it = segments_sort.begin(); it + key_nums < std::prev(segments_sort.end()); it = it + key_nums) {
            //     alignas(align_val) Simd_Value *slope_significand_simd_tmp = aligned_new<Simd_Value>(key_nums);
            //     std::vector<Segment> simd_segments(it, it + key_nums);
            //     idx += key_nums;
            //     for (auto i = 0, its = simd_segments.begin(); its != simd_segments.end(); ++its, ++i) {
            //         auto &s = *its;
            //         slope_significand_simd_tmp[i] = static_cast<Simd_Value>(s.slope_significand); // float to double
            //     }
            //     slope_significand_simd.emplace_back(slope_significand_simd_tmp);
            // }
            //
            // for (typename std::vector<Segment>::iterator it = segments_sort.begin(); it + key_nums < std::prev(segments_sort.end()); it = it + key_nums) {
            //     alignas(align_val) Simd_Value *slope_exponent_simd_tmp = aligned_new<Simd_Value>(key_nums);
            //     std::vector<Segment> simd_segments(it, it + key_nums);
            //     for (auto i = 0, its = simd_segments.begin(); its != simd_segments.end(); ++its, ++i) {
            //         auto &s = *its;
            //         slope_exponent_simd_tmp[i] = static_cast<Simd_Value>(s.slope_exponent); // float to double
            //     }
            //     slope_exponent_simd.emplace_back(slope_exponent_simd_tmp);
            // }
            //
            // for (typename std::vector<Segment>::iterator it = segments_sort.begin(); it + key_nums < std::prev(segments_sort.end()); it = it + key_nums) {
            //     alignas(align_val) Simd_Value *intercept_simd_tmp = aligned_new<Simd_Value>(key_nums);
            //     std::vector<Segment> simd_segments(it, it + key_nums);
            //     for (auto i = 0, its = simd_segments.begin(); its != simd_segments.end(); ++its, ++i) {
            //         auto &s = *its;
            //         intercept_simd_tmp[i] = static_cast<Simd_Value>(s.intercept); // Simd_Value to double
            //     }
            //     intercept_simd.emplace_back(intercept_simd_tmp);
            // }
            //
            // for (typename std::vector<Segment>::iterator it = segments_sort.begin(); it + key_nums < std::prev(segments_sort.end()); it = it + key_nums) {
            //     alignas(align_val) Simd_Value *covered_tmp = aligned_new<Simd_Value>(key_nums);
            //     std::vector<Segment> simd_segments(it, it + key_nums);
            //     max_cover = 0;
            //     min_cover = INT_MAX;
            //     for (auto i = 0, its = simd_segments.begin(); its != simd_segments.end(); ++its, ++i) {
            //         auto &s = *its;
            //         auto covered = s.covered;
            //         covered_tmp[i] = static_cast<Simd_Value> (covered);
            //         min_cover = min_cover < covered ? min_cover : covered;
            //         max_cover = max_cover > covered ? max_cover : covered;
            //     }
            //     covered_simd.emplace_back(covered_tmp);
            //     max_min_covered = use_max ? max_cover : min_cover; // 填充法或截断法
            //     cover_length.emplace_back(max_min_covered);
            // }
            //
            // for (typename std::vector<Segment>::iterator it = segments_sort.begin(); it + key_nums < std::prev(segments_sort.end()); it = it + key_nums) {
            //     alignas(align_val) Simd_Value *first_tmp = aligned_new<Simd_Value>(key_nums);
            //     std::vector<Segment> simd_segments(it, it + key_nums);
            //     for (auto i = 0, its = simd_segments.begin(); its != simd_segments.end(); ++its, ++i) {
            //         auto &s = *its;
            //         first_tmp[i] = static_cast<Simd_Value> (s.first);
            //     }
            //     first_simd.emplace_back(first_tmp);
            // }

            for (typename std::vector<Segment>::iterator it = segments_sort.begin(); it + key_nums < std::prev(segments_sort.end()); it = it + key_nums) {
                alignas(align_val) Simd_Value *slope_significand_simd_tmp = aligned_new<Simd_Value>(key_nums);
                alignas(align_val) Simd_Value *slope_exponent_simd_tmp = aligned_new<Simd_Value>(key_nums);
                alignas(align_val) Intercept_Value *intercept_simd_tmp = aligned_new<Intercept_Value>(key_nums * 2);
                alignas(align_val) Covered_Value *covered_tmp = aligned_new<Covered_Value>(key_nums);
                alignas(align_val) Covered_Value *first_tmp = aligned_new<Covered_Value>(key_nums);
                // Simd_Value max_cover = 0;
                // Simd_Value min_cover = INT_MAX;
                // Simd_Value max_min_covered = 0;

                std::vector<Segment> simd_segments(it, it + key_nums);
                idx += key_nums;

                for (auto i = 0, its = simd_segments.begin(); its != simd_segments.end(); ++its, ++i) {
                    auto &s = *its;
                    auto covered = s.covered;
                    slope_significand_simd_tmp[i] = static_cast<Simd_Value>(s.slope_significand);
                    slope_exponent_simd_tmp[i] = static_cast<Simd_Value>(s.slope_exponent);
                    intercept_simd_tmp[i] = static_cast<Simd_Value>(s.intercept);
                    intercept_simd_tmp[i + key_nums] = static_cast<Intercept_Value>(s.intercept);
                    covered_tmp[i] = static_cast<Covered_Value> (covered);
                    first_tmp[i] = static_cast<Covered_Value> (s.first);
                    min_cover = min_cover < covered ? min_cover : covered;
                    max_cover = max_cover > covered ? max_cover : covered;
                }

                slope_significand_simd.emplace_back(slope_significand_simd_tmp);
                slope_exponent_simd.emplace_back(slope_exponent_simd_tmp);
                intercept_simd.emplace_back(intercept_simd_tmp);
                first_simd.emplace_back(first_tmp);
                covered_simd.emplace_back(covered_tmp);
                max_min_covered = use_max ? max_cover : min_cover;
                if (max_min_covered % 2 == 1) // we need to make it even
                    max_min_covered--;
                cover_length.emplace_back(max_min_covered);
            }
            corrections_simd.resize(cover_length.size() , 0);
        }

        void create_correction() {
            // corrections_simd.resize(cover_length.size(), 0);
            for (int i = 0;i < cover_length.size(); i++) {
                Covered_Value cover_length_tmp = cover_length[i];
                Covered_Value *first_tmp = first_simd[i];
                // Simd_Value *cover_tmp = covered_simd[i];
                alignas(align_val) Correction_Value *corrections_simd_tmp = aligned_new<Correction_Value>(cover_length_tmp * key_nums);
                if (cover_length_tmp > 0)
                    for (Covered_Value k = 0; k < key_nums; k++) {
                        corrections_simd_tmp[k] = corrections_vector[first_tmp[k]];
                        // if (cover_length_tmp > 1)
                            // corrections_simd_tmp[k + key_nums] = corrections_vector[first_tmp[k] + 1];
                        // corrections_simd_tmp[k + key_nums] = corrections_vector[first_tmp[k] + 1];
                    }
                for (Covered_Value j = 1; j < cover_length_tmp; j++) {
                    for (Covered_Value k = 0; k < key_nums; k++) {
                            corrections_simd_tmp[j * key_nums + k] = corrections_vector[j + first_tmp[k]];
                            // corrections_simd_tmp[j * key_nums + k] = corrections_vector[j + first_tmp[k]] - corrections_vector[j - 1 + first_tmp[k]];
                            // if (j + 1 < cover_length_tmp && j + 1 < cover_tmp[k])
                                // corrections_simd_tmp[j * key_nums + k + key_nums] = corrections_vector[j + 1 + first_tmp[k]] - corrections_vector[j + first_tmp[k]];
                            // corrections_simd_tmp[j * key_nums + k + key_nums] = corrections_vector[j + 1 + first_tmp[k]] - corrections_vector[j + first_tmp[k]];

                    }
                }
                corrections_simd[i] = corrections_simd_tmp;
            }
        }

        // Simd_Value corrections_vector_residual_size = 0;

        // std::vector<Simd_Value> corrections_vector_residual;
        // // int64_t* corrections_vector_residual;
        // void corrections_residual_init() {
        //     // corrections_vector_residual.resize(corrections_vector_residual_size);
        //      corrections_vector_residual.resize(n, 0);
        //      // corrections_vector_residual = aligned_new<int64_t> (n);
        //     Simd_Value correct_pointers = -1;
        //     Simd_Value key_nums_tmp = key_nums;
        //     for(int i = 0; i < slope_significand_simd.size(); i++) {
        //         Simd_Value *first_tmp = first_simd[i]; // 每个线段的第一个位置
        //         Simd_Value *cover_tmp = covered_simd[i];
        //         Simd_Value cover_length_tmp = cover_length[i];
        //         for (K k = 0; k < key_nums_tmp; k++){ // save the data to the right pos{
        //             corrections_vector_residual[++correct_pointers] = static_cast<int32_t> (get_correction(corrections.data(), n, first_tmp[k], signs));
        //                 // corrections_vector[first_tmp[k]];
        //                 // get_correction(corrections.data(), n, first_tmp[k], signs);
        //                 // corrections_vector[first_tmp[k]];
        //         }
        //
        //         for (Simd_Value pos = 1; pos < cover_length_tmp; pos++) {
        //             for (K k = 0; k < key_nums_tmp; k++) {
        //                 corrections_vector_residual[++correct_pointers] = static_cast<int32_t> (get_correction(corrections.data(), n, first_tmp[k] + pos, signs));
        //                     // corrections_vector[first_tmp[k] + pos];
        //                     // get_correction(corrections.data(), n, first_tmp[k] + pos, signs);
        //                     // corrections_vector[first_tmp[k] + j];
        //             }
        //         }
        //
        //         for (K k = 0; k < key_nums_tmp; k++) { // 剩余的值用单个循环解码
        //             // auto covered = cover_tmp[k];
        //             if (cover_length_tmp < cover_tmp[k]) {
        //                 for (Simd_Value pos = cover_length_tmp; pos < cover_tmp[k]; pos++){
        //                     // corrections_vector_residual_size++;
        //                     corrections_vector_residual[++correct_pointers] = static_cast<int32_t> (get_correction(corrections.data(), n, first_tmp[k] + pos, signs));
        //                         // corrections_vector[first_tmp[k] + pos];
        //                         // get_correction(corrections.data(), n, first_tmp[k] + pos, signs);
        //                         // corrections_vector[first + pos];
        //                 }
        //             }
        //         }
        //     }
        //     for(auto it = segments_sort.begin() + idx; it < std::prev(segments_sort.end()); it++) {
        //         auto& s = *it;
        //         auto covered = s.covered;
        //         auto first = s.first;
        //         for (Simd_Value pos = 0; pos < s.covered; pos++){
        //             corrections_vector_residual[++correct_pointers] = get_correction(corrections.data(), n, first + pos, signs);
        //                 // corrections_vector[first + pos];
        //                 // get_correction(corrections.data(), n, s.first + pos, signs);
        //                 // corrections_vector[first + pos];
        //         }
        //     }
        // }

        std::vector<K> decode() {
            std::vector<K> out;
            out.resize(n);
            // alignas(align_val) Simd_Value *result = aligned_new<Simd_Value>(key_nums); // 存储结果
            auto start1 = std::chrono::high_resolution_clock::now();
            for (auto it = segments.begin(); it != std::prev(segments.end()); ++it) {
                auto& s = *it;
                auto covered = s.covered;
                auto significand = s.slope_significand;
                auto exponent = s.slope_exponent;
                auto intercept = s.intercept;
                auto first = s.first;
                for (Covered_Value j = 0; j < covered; ++j){
                    //                    out[j] = ((j * significand) >> exponent) + intercept + get_correction(corrections.data(), n, j + first, signs);
                    // out[j + first] = 1;
                    // out[j + first] = result[2];
                    out[j + first] = ((j * significand) >> exponent) + intercept + corrections_vector[j +first];
                    // + intercept + corrections_vector[j +first];
                    // out[j + first] = ((j * significand) >> exponent) + intercept;
                    // out[j + first] = ((j * significand) >> exponent) + intercept + s.get_correction(corrections.data(), n, j + first, signs);
                }
                // out += covered;
            }
            auto end1 = std::chrono::high_resolution_clock::now();
            auto duration1 = std::chrono::duration_cast<std::chrono::microseconds>(end1 - start1);
            duration = duration1.count();
            // for (K i = 0; i < n; i++)
            //     out[i] = 1;
            return out;
        }

        uint64_t duration;

        std::vector<K>  simd_decode_512i(){
            std::vector<K> output;
            output.resize(n);
            Covered_Value pointers = -1;
            // Simd_Value correct_pointers = -1;
            Covered_Value key_nums_tmp = key_nums * 2;
             // alignas(align_val) Simd_Value *result = aligned_new<Simd_Value>(n); // 存储结果
            alignas(align_val) Correction_Value *result_int32 = aligned_new<Correction_Value>(key_nums_tmp); // 存储结果
            // alignas(align_val) Simd_Value *result = aligned_new<Simd_Value>(key_nums); // 存储结果
            auto start1 = std::chrono::high_resolution_clock::now();
            for(int i = 0; i < slope_significand_simd.size(); i++) {
                Simd_Value *slope_significand_p = slope_significand_simd[i];
                Simd_Value *slope_exponent_p = slope_exponent_simd[i];
                Intercept_Value *intercept_p = intercept_simd[i];
                Correction_Value *corrections_p = corrections_simd[i]; // 第一个值的地址

                Covered_Value *first_tmp = first_simd[i]; // 每个线段的第一个位置
                Covered_Value *cover_tmp = covered_simd[i];
                Covered_Value cover_length_tmp = cover_length[i];
                // cout << "cover_length_tmp: " << cover_length_tmp << endl;
                if (cover_length_tmp == 0)
                    continue;

                __m512i slope_correct_v, result_v, contact_int32_v;
                __m256i int32_v2, int32_v1;

                __m512i intercept_v = _mm512_load_epi32(intercept_p);
                // __m512i  = _mm512_setzero_si512();

                // __m256i int32_v1 = _mm512_cvtepi64_epi32(intercept_v);
                // __m256i int32_v2 = _mm512_cvtepi64_epi32(intercept_v);
                // intercept_v = _mm512_inserti64x4(intercept_v, int32_v1, 0);
                // intercept_v = _mm512_inserti64x4(intercept_v, int32_v2, 1);
                // contact_int32_v = _mm512_inserti64x4(contact_int32_v, int32_v1, 0);
                // contact_int32_v = _mm512_inserti64x4(contact_int32_v, int32_v2, 1);
                // cout << "Debug 1" << endl;
                __m512i corrections_v = _mm512_load_epi32(corrections_p); // 误差值
                result_v = _mm512_add_epi32(intercept_v, corrections_v); // 误差差值存储
                // cout << "Debug 2" << endl;

                __m512i slope_significand_v_tmp = _mm512_load_epi64(slope_significand_p);
                __m512i slope_significand_v = _mm512_load_epi64(slope_significand_p);
                __m512i slope_exponent_v = _mm512_load_epi64(slope_exponent_p);
                slope_correct_v = _mm512_srlv_epi64(slope_significand_v, slope_exponent_v);
                int32_v2 = _mm512_cvtepi64_epi32(slope_correct_v);
                int32_v1 = _mm256_setzero_si256();
                contact_int32_v = _mm512_inserti64x4(contact_int32_v, int32_v1, 0);
                contact_int32_v = _mm512_inserti64x4(contact_int32_v, int32_v2, 1);
                result_v = _mm512_add_epi32(result_v, contact_int32_v);

                // _mm512_store_epi64(result, result_v); // save the data
                _mm512_store_epi32(result_int32, result_v); // save the data

                for (Covered_Value k = 0; k < key_nums_tmp; k++){ // save the data to the right pos{
                // output[++pointers] = corrections_vector_residual[pointers] + result[k];
                    output[++pointers] = result_int32[k];
                    // output[++pointers] = result[k];
                    // output[++pointers] = 0;
                }
                // cout << "Debug 3" << endl;

                for (Covered_Value j = 2; j < cover_length_tmp; j= j + 2) {
                    corrections_p += key_nums_tmp; // 指向下一个值
                    // corrections_v = _mm512_load_epi64(corrections_p); // 误差值
                    // result_v = _mm512_add_epi64(result_v, corrections_v); // 误差差值存储
                    slope_significand_v = _mm512_add_epi64(slope_significand_v, slope_significand_v_tmp);
                    slope_correct_v = _mm512_srlv_epi64(slope_significand_v, slope_exponent_v);
                    int32_v1 = _mm512_cvtepi64_epi32(slope_correct_v);
                    contact_int32_v = _mm512_inserti64x4(contact_int32_v, int32_v1, 0);

                    slope_significand_v = _mm512_add_epi64(slope_significand_v, slope_significand_v_tmp);
                    slope_correct_v = _mm512_srlv_epi64(slope_significand_v, slope_exponent_v);
                    int32_v2 = _mm512_cvtepi64_epi32(slope_correct_v);


                    contact_int32_v = _mm512_inserti64x4(contact_int32_v, int32_v2, 1);

                    result_v = _mm512_add_epi32(intercept_v, contact_int32_v);
                    corrections_v = _mm512_load_epi32(corrections_p); // 误差值
                    result_v = _mm512_add_epi32(result_v, corrections_v);


                    // _mm512_store_epi64(result, result_correct_v);
                    // _mm512_store_epi64(result, slope_correct_v);
                    _mm512_store_epi32(result_int32, result_v);

                     for (Covered_Value k = 0; k < key_nums_tmp; k++) {
                        // output[++pointers] = corrections_vector_residual[pointers] + result[k];
                         output[++pointers] = result_int32[k];
                        // output[++pointers] = result[k];
                         // output[++pointers] = 1;
                     }


                    // result += key_nums;

                }

            // total_calculated += key_nums * cover_length_tmp;
            // cout << "Debug 5" << endl;
             for (Covered_Value k = 0; k < key_nums; k++) { // 剩余的值用单个循环解码
                 auto covered = cover_tmp[k];
                 if (cover_length_tmp < covered) {
                 auto first = first_tmp[k];
                 auto slope_significand = slope_significand_p[k];
                 auto slope_exponent = slope_exponent_p[k];
                 auto intercept = intercept_p[k];
                     for (Covered_Value pos = cover_length_tmp; pos < covered; pos++){
                        output[++pointers] = ((slope_significand * pos) >> slope_exponent) + intercept + corrections_vector[first + pos];
                         // output[++pointers] = ((slope_significand * pos) >> slope_exponent) + intercept + corrections_vector_residual[pointers];
                         // output[++pointers] = ((slope_significand * pos) >> slope_exponent) + intercept;
                     }
                 }
             }
                // cout << "Debug 7" << endl;
            }
            // cout << "Debug 6" << endl;
             for(auto it = segments_sort.begin() + idx; it < std::prev(segments_sort.end()); it++) {
                 auto& s = *it;
                 auto covered = s.covered;
                 auto slope_significand = s.slope_significand;
                 auto slope_exponent = s.slope_exponent;
                 auto intercept = s.intercept;
                 auto first = s.first;
                 for (Covered_Value pos = 0; pos < covered; pos++){
                     output[++pointers] = ((slope_significand * pos) >> slope_exponent) + intercept + corrections_vector[first + pos];
                     // output[++pointers] = ((slope_significand * pos) >> slope_exponent) + intercept + corrections_vector_residual[pointers];
                     // output[++pointers] = ((slope_significand * pos) >> slope_exponent) + intercept;
                 }
             }
            auto end1 = std::chrono::high_resolution_clock::now();
            auto duration1 = std::chrono::duration_cast<std::chrono::microseconds>(end1 - start1);
            duration = duration1.count();
            // for (K i = 0; i < n; i++) {
            //     output[++pointers] = result[2];
            // }
                // output[i] += corrections_vector_residual[i];
            return output;
        }


//
        static void set_correction(uint64_t* corrections_val, uint64_t n, uint64_t i, uint64_t value) {
            auto idx = get_correction_bit_offset(n, i);
            sdsl::bits::write_int(corrections_val + (idx >> 6), value, idx & 0x3F, BIT_WIDTH(Epsilon));
        }

        static uint64_t get_correction_bit_offset(uint64_t n, uint64_t i) {
            uint8_t bpc = BIT_WIDTH(Epsilon);
            if (i % extraction_density == 0)
                return bpc * (i / extraction_density);
            return bpc * (i + n / extraction_density - i / extraction_density);
        }

        static int64_t get_correction(const uint64_t* corrections_val, uint64_t n, uint64_t i, const sdsl::bit_vector& signs)  {
            auto idx = get_correction_bit_offset(n, i);
            uint64_t correction = sdsl::bits::read_int(corrections_val + (idx >> 6u), idx & 0x3F, BIT_WIDTH(Epsilon));
            return ((signs[i] == 0) ? correction : (-correction));
        }
//
     };

    // 保持当前对齐方式后，不对齐
    #pragma pack(push, 1)

    // 线段结构，包括截距、斜率、误差值等
    template <typename K, uint64_t Epsilon, uint64_t EpsilonRecursive, typename Floating>
    struct PGMIndex<K, Epsilon, EpsilonRecursive, Floating>::Segment { // 一个分割线段
        Covered_Value first; // 第一个位置
        Intercept_Value intercept; // 截距
        uint8_t slope_exponent; // 斜率的指数
        uint64_t slope_significand; // 斜率的有效数字
        Covered_Value covered;

        Segment() = default;

        explicit Segment(position_type first):
            first(first),
            // intercept(std::numeric_limits<decltype(intercept)>::max()),
            intercept(0),
            slope_exponent(0),
            slope_significand(0),
            covered(0) {}

        // construct segment：get slope and intercept
        template <typename RandomIt>
        Segment(const canonical_segment& cs, // 线段数据，获取斜率和截距，以及残差
            uint64_t n, // 数据集的大小
            uint64_t i, // 线段的起始位置
            uint64_t j, // 线段的终止位置
            RandomIt data, // 数据集
            uint64_t& errorPointCount, // 误差点的数量
            uint64_t* corrections_ptr, // 误差值的指针
            sdsl::bit_vector& signs, // 正负标记
            uint8_t bpc, // 误差值的位宽
            position_type corrections_offset) { // 误差值的偏移

            first = cs.get_first_x(); // 获取线段的起始位置
            if (first == n) {
                covered = 0;
                std::cout << first << endl;
                return;
            }

            auto [cs_significand, cs_exponent, cs_slope_float, cs_intercept] = cs.get_fixed_point_segment(first, j - i + 1); // 获取线段的斜率和截距，定点表示法
            if (cs_intercept > std::numeric_limits<decltype(intercept)>::max()) { // 截距超过最大值
                throw std::overflow_error("Change the type of Segment::intercept to uint64");
            }
            if (cs_intercept < 0) // 截距小于0
                throw std::overflow_error("Unexpected intercept < 0");

            slope_exponent = cs_exponent;
            slope_significand = cs_significand;
            intercept = cs_intercept;
            covered = (j - i);

            if (first == n - 1) { // 最后一个点单点分割时候特殊判断
                intercept = data[first];
                slope_exponent = 0;
                slope_significand = 0;
                auto error = static_cast<int64_t> (static_cast<int64_t> (data[first]) - approximate(first)); // __int128 ->  int64_t
                uint64_t correction_val = std::abs(error);
                set_correction(corrections_ptr, n, first, correction_val);
                signs[first] = 0;
                return;
            }

            for (auto p = first; p < j; p++) {
                auto error = static_cast<int64_t> (data[p]) - approximate(p); // __int128 ->  int64_t
                uint64_t correction = std::abs(error);
                set_correction(corrections_ptr, n, p, correction);
                bool sign = error > 0;
                signs[p] = sign ? 0 : 1;
                if (std::abs(error) > (Epsilon + 1)) {
                    errorPointCount++;
                }
            }
        }

        // void set_correction(uint64_t* corrections_val, uint64_t n, uint64_t i, uint64_t value) {
        //     auto idx = get_correction_bit_offset(n, i);
        //     sdsl::bits::write_int(corrections_val + (idx >> 6), value, idx & 0x3F, BIT_WIDTH(Epsilon));
        // }
        //
        // uint64_t get_correction_bit_offset(uint64_t n, uint64_t i) {
        //     uint8_t bpc = BIT_WIDTH(Epsilon);
        //     if (i % extraction_density == 0)
        //         return bpc * (i / extraction_density);
        //     return bpc * (i + n / extraction_density - i / extraction_density);
        // }
        //
        // int64_t get_correction(const uint64_t* corrections_val, uint64_t n, uint64_t i, const sdsl::bit_vector& signs)  {
        //     auto idx = get_correction_bit_offset(n, i);
        //     uint64_t correction = sdsl::bits::read_int(corrections_val + (idx >> 6u), idx & 0x3F, BIT_WIDTH(Epsilon));
        //     return ((signs[i] == 0) ? correction : (-correction));
        // }

        friend inline bool operator<(const Segment& s, const K& k) { return s.first < k; }
        friend inline bool operator<(const K& k, const Segment& s) { return k < s.first; }
        friend inline bool operator<(const Segment& s, const Segment& t) { return s.covered > t.covered; }

        operator K() { return first; };

        int64_t approximate(uint64_t i) const {
            return (int64_t(slope_significand * (i - first)) >> slope_exponent) + intercept;
        }

        inline int64_t operator()(const K& p) const { // 计算近似值
            return approximate(p);
        }
    };

    #pragma pack(pop)

}
